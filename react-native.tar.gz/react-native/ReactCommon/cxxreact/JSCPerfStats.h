// Copyright 2004-present Facebook. All Rights Reserved.

#pragma once

#include <JavaScriptCore/JSContextRef.h>

namespace facebook {
namespace react {

void addJSCPerfStatsHooks(JSGlobalContextRef ctx);

} }
