// Copyright 2004-present Facebook. All Rights Reserved.

#pragma once

#include <string>

namespace facebook { namespace gloginit {

void initialize(const char* tag = "ReactNativeJNI");

}}
