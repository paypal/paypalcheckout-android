// Copyright 2004-present Facebook. All Rights Reserved.
namespace facebook {
namespace react {
  void ThisWhatsLeftOfTheOldBridge() {
  }
}
}
